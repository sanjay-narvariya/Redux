
import { BrowserRouter as Router,Route,Routes } from "react-router-dom";
import AdminLogin from "./components/admin/adminlogin/AdminLogin";
import Dashboard from "./components/admin/adminlogin/Dashboard";
import HomePage from "./components/userinterface/homepage/HomePage"
function App() {
  return (
   <div>
    <Router>
      <Routes>
        <Route element={<AdminLogin/>} path="/adminlogin"></Route>
        <Route element={<Dashboard/>} path="/dashboard/*"></Route>
        <Route element={<HomePage/>} path="/homepage"></Route>
        
      </Routes>
    </Router>
   
   </div>
  );
}

export default App;
